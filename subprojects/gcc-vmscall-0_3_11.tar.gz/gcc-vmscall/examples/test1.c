#include <stdarg.h>
#include <stdio.h>
/*
compile with:
gcc -o test1 test1.c 
*/
int __attribute__((__vmscall__)) t (int c , ...)
{
    va_list ap;

    int r , i;
    int cnt;

    va_count (cnt);

    printf ("t called with %d arguments\n" , cnt);
    r = c;
    va_start (ap , c);
    for (i = 0; i < c; i++)
    {
        printf ("arg %d = %d\n" , i , r);
	r = va_arg (ap , int);
    }
    va_end (ap);

    printf ("end\n\n");
    return r;
}
int main ()
{
    t (1);
    t (2 , 3);
    t (3 , 4 , 5);
    return 0;
}
