/* No thread support. */
